
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

DROP TABLE IF EXISTS student;
CREATE TABLE student (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, name VARCHAR (32));

INSERT INTO student (id, name) VALUES (1, 'user1');
INSERT INTO student (id, name) VALUES (2, 'user2');
INSERT INTO student (id, name) VALUES (3, 'user3');
INSERT INTO student (id, name) VALUES (4, 'user4');
INSERT INTO student (id, name) VALUES (5, 'user5');


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
